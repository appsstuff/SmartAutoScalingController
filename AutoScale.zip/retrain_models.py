import os
import pandas as pd
import numpy as np
from xgboost import XGBClassifier
from sklearn.gaussian_process import GaussianProcessRegressor
from tensorflow.keras.models import load_model, save_model
from sklearn.preprocessing import StandardScaler
import joblib
from config_multi import AUTO_SCALE_SERVICES

print(" Starting bulk model retraining process")

def collect_live_data(pod_name):
    log_path = f"/data/live_data/{pod_name}_live_data.csv"
    if not os.path.exists(log_path):
        print(f" No data found for {pod_name}")
        return None, None

    df = pd.read_csv(log_path)
    feature_columns = ["hour_of_day", "day_of_week", "cpu_usage_lag_1", "cpu_usage_lag_5", "cpu_roll_mean_10", "mem_usage", "req_rate"]
    X_new = df[feature_columns].values
    y_new = df["decision"].map({"scale_down": 0, "no_change": 1, "scale_up": 2}).values
    return X_new, y_new

def retrain_for_service(svc_config, index):
    pod_name = svc_config["pod_name"]
    namespace = svc_config.get("namespace", "default")
    seq_length = svc_config.get("seq_length", 10)

    X_new, y_new = collect_live_data(pod_name)
    if X_new is None or len(X_new) < 50:
        print(f" Not enough data to retrain {pod_name}")
        return

    try:
        # Load models
        gpr = joblib.load(f"models/gpr_model_{pod_name}.pkl")
        clf = XGBClassifier()
        clf.load_model(f"models/xgb_model_{pod_name}.json")
        model_lstm = load_model(f"models/lstm_model_{pod_name}.h5")
        scaler = joblib.load(f"models/scaler_{pod_name}.pkl")

        # Scale data
        X_scaled = scaler.transform(X_new)

        # Retrain GPR
        print(f" Retraining GPR for {pod_name}")
        gpr.fit(X_scaled, y_new)
        joblib.dump(gpr, f"models/gpr_model_{pod_name}.pkl")

        # Retrain XGBoost
        print(f" Retraining XGBoost for {pod_name}")
        clf.fit(X_scaled, y_new)
        clf.save_model(f"models/xgb_model_{pod_name}.json")

        # Retrain LSTM
        from utils import create_sequence
        print(f" Retraining LSTM for {pod_name}")
        seq_input = create_sequence(X_scaled, seq_length)
        model_lstm.fit(seq_input, y_new, epochs=5, batch_size=32, verbose=0)
        model_lstm.save(f"models/lstm_model_{pod_name}.h5")

        print(f" Models updated for {pod_name}")

    except Exception as e:
        print(f" Failed to retrain for {pod_name}: {e}")

if __name__ == "__main__":
    for idx, svc in enumerate(AUTO_SCALE_SERVICES):
        retrain_for_service(svc, idx)